{
  "code": 0
  ,"msg": ""
  ,"data": {
    "username": "贤心"
    ,"sex": "男"
    ,"role": 1
  }
}